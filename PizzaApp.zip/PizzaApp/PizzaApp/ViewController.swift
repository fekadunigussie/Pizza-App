//
//  ViewController.swift
//  PizzaApp
//
//  Created by Fekadu Abebe on 10/19/17.
//  Copyright © 2017 Fekadu Abebe. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var  numberOfOrders:Int?
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numberOfOrders ?? 20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") else {
            fatalError("No cell created or bad identifier")
        }
        
        
        cell.textLabel?.text = array[indexPath.row].joined(separator: ", ")
        return cell
    }
    

   
    @IBOutlet weak var PizzaList: UITableView!
    
    
    var array:[Set<String>] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        PizzaList.dataSource = self
        PizzaList.delegate = self
        pizzaParse(completion:{(pizza,ingredients,error) in
            guard let pizza = pizza else {return}
            array = pizza
          
            //print(array)
        })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func pizzaParse ( completion:([Set<String>]?,[String]?, Error?)->()){
        guard let path = Bundle.main.path(forResource: "assignment", ofType: "json")else {
            return}
        do
        {
        let data = try Data(contentsOf:URL(fileURLWithPath: path))
        
            let myDecoder = JSONDecoder()
            
            let information = try myDecoder.decode([Pizza].self, from: data)
            var set:Set<String> = Set()
            for x in information {
                for y in x.toppings {
                    set.insert(y)
                }
                
            }
            let countedSet:NSCountedSet = NSCountedSet()
            for x in information{
                countedSet.add(x.toppings)
            }
            let toppingCount = countedSet.map{($0,countedSet.count(for: $0))
                
            }
            let countOrder = toppingCount.sorted{
                $0.1 > $1.1
                
            }
            guard let a = (countOrder.map{$0.0}) as? [Set<String>] else {
               // print("1")
                return}
            completion(a, Array(set), nil)
            
        }catch let error {
            completion(nil,nil, error)
            return
        }
    }
    
        
}

