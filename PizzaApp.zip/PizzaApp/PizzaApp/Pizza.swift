//
//  Pizza.swift
//  PizzaApp
//
//  Created by Fekadu Abebe on 10/19/17.
//  Copyright © 2017 Fekadu Abebe. All rights reserved.
//

import Foundation
struct Pizza: Codable{
    let toppings:Set<String>
    
}
