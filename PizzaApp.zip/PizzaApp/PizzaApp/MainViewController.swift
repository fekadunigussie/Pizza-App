//
//  MainViewController.swift
//  PizzaApp
//
//  Created by Fekadu Abebe on 10/20/17.
//  Copyright © 2017 Fekadu Abebe. All rights reserved.
//

import Foundation
import UIKit


class MainViewController:UIViewController{
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else{return}
        guard let nextView = segue.destination as? ViewController else{return}
        
        switch identifier{
        case "GoTo10":
            nextView.numberOfOrders = 10
            
        case "GoTo5":
            nextView.numberOfOrders = 5
        default:
            nextView.numberOfOrders = 20
            
        }
    }
    
    
    
}
